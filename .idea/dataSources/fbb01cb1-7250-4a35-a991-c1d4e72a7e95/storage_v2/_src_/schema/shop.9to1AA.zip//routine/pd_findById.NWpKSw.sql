create
    definer = root@localhost procedure pd_findById(IN sid int)
BEGIN
    select * from student where id=sid;
end;

