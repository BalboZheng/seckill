create
    definer = root@localhost procedure pro_test()
BEGIN
      select * from student;        
end;

