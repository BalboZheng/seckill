create
    definer = root@localhost procedure pd_testInOut(INOUT str varchar(20))
begin
     select str;
     
     set str='666';
end;

