create
    definer = root@localhost procedure pro_findById(IN sid int)
BEGIN
          select * from student where id=sid;

end;

