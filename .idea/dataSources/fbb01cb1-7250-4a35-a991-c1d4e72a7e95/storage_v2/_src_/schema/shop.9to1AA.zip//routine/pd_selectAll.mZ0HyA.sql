create
    definer = root@localhost procedure pd_selectAll()
BEGIN
    select * from student;
end;

