create
    definer = root@localhost procedure pro_ifelse(IN num int, OUT str varchar(20))
BEGIN
     
    if  num=1  THEN
         SET str='春季'; 
    elseif  num=2  THEN
         SET str='夏季'; 
	  elseif  num=3  THEN
         SET str='秋季'; 
    ELSE 
         SET str='东季';   
     end if;

end;

