create
    definer = root@localhost procedure pro_outtest(INOUT str varchar(20))
BEGIN
    select  str;
    set str='hello,world!';

end;

