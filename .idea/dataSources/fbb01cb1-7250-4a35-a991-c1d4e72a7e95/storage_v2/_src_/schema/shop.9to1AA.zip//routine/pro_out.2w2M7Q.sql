create
    definer = root@localhost procedure pro_out(OUT str varchar(20))
BEGIN
        
    set str='hello,world!';

end;

