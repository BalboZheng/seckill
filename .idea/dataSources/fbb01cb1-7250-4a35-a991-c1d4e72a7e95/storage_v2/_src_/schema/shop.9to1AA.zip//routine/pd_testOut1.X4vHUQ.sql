create
    definer = root@localhost procedure pd_testOut1(OUT str varchar(20))
BEGIN
   set str='大吉大利，今晚吃鸡';
end;

