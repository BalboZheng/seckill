create
    definer = root@localhost procedure pd_testIf1(IN num int, OUT str varchar(20))
begin
     if num=1 THEN
     set str='一';
     
     ELSEIF num=2 THEN 
      set str='二';
    
     end if;
end;

