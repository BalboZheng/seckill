create
    definer = root@localhost procedure pd_testwhile(IN num int, OUT sums int)
BEGIN

      -- 定义变量
      DECLARE  i     int DEFAULT 1;
      DECLARE  vsum  int DEFAULT 0;
     -- 循环判断  true执行
      while i<=num do 
      set vsum=vsum+i;
      set i=i+1;
     -- j结束循环
      end while;
     set sums=vsum;
end;

